/*
midterm/ bank account appplication

author: seho eom
*/

#include <iostream>
#include <vector>
#include <iomanip>
#include <string>

using namespace std;

#define maxClient 10
#define numClient 10
#define numSize 10


struct customerInformation {
	int accountNumber[numSize];
	int pin;
	int openedDate;
	int accountType[numSize];
	int iNumber;
	float accountBalance[numSize];
	string checkingAccount;
	string savingAccount;
};

struct date {
	int month;
	int day;
	int year;
};

struct  accountType {
	string checkingAccount;
	string savingAccount;
};


enum Menu {
	menu_insert,
	menu_output,
	menu_check,
	menu_transaction,
	menu_search,
	menu_sort,
	menu_exit
};

void depositeAmount(int a, int b, int saving);
void withdrawalAmount(int a, int b, int deposit);
void calculateAmount(int a, int b, int credit);



int main() {
	customerInformation  clientArr[maxClient] = {};
	accountType accountArr[numClient] = {};

	int customerCount = 0;
	int cid = 1;
	int amount = 0;
	int more = 0;
	int balance = 0;
	int less = 0;

	// use these variable to search data

	//char accountNumber[] = {};
	//char;

	while (true) {

		system("cls");
		cout << "-----Main Menu-----" << endl;
		cout << "1. Create Account" << endl;
		cout << "2. Display Account" << endl;
		cout << "3. Check Balance" << endl;
		cout << "4. Make Transaction " << endl;
		cout << "5. Search Account" << endl;
		cout << "6. Sort the account" << endl;
		cout << "7. Exit" << endl;
		int imenu;
		cin >> imenu;


		// to prevent the wrong value to be added

		if (cin.fail()) {
			cin.clear();
			cin.ignore(1024, '\n');
			continue;
		}

		//exiting menu

		if (imenu == menu_exit)
			break;

		switch (imenu) {
		case menu_insert:
		{
			//to prevent the number of client to go over the max limit
			if (customerCount == maxClient)
				break;

			// Register Client

			cout << "-----Client Register-----" << endl;
			cout << "Enter the account number: " << endl;
			cin >> clientArr[customerCount].accountNumber;
			cin.ignore();


			cout << "Enter the account type: " << endl;
			cin >> clientArr[customerCount].accountType;
			cin.ignore();

			cout << "Enter the opening date: " << endl;
			cin >> clientArr[customerCount].openedDate;
			cin.ignore();

			cout << "Enter the pin: " << endl;
			cin >> clientArr[customerCount].pin;


			++customerCount;

			cout << "saving complete" << endl;
			break;

		case menu_output:
			system("cls");
			{
				for (int i = 0; i < customerCount; i++)
				{
					cout << "Account Number" << clientArr[i].accountNumber;
					cout << "PIN Number" << clientArr[i].pin;
					cout << "Opened Date" << clientArr[i].openedDate;
					cout << "Account Type" << clientArr[i].accountType;
					cout << "Current Balance " << clientArr[i].accountBalance;
				}
			}
			break;

		case menu_check:
			system("cls");
			cout << "cheking balance" << endl;
			cout << "Your ramaining balance in checking account  is ... " << clientArr.accountBalance[numSize] << endl;
			cout << "Your ramaining balance in saving account  is ... " << clientArr.accountBalance[numSize] << endl;

			break;

		case menu_transaction:
			system("cls");

			cout << "Enter the amount to deposit(credit) : ";
			cin >> more;
			balance += more;
		}

		float amt;
		cout << "Withdrwal";
		cout << "Enter the amount to withdraw (debit): ";
		cin >> amt;
		balance -= amt;
		

		break;
	
		case menu_search:

			system("cls");
			cout << "----- Search Account -----" << endl;


			cin.ignore(1024, '\n');
			cout << "Enter the account number to be searched : \n";
			cin.getline(accountNumber, numSize);
			cout << "Enter the account type to be searched : \n";
			cin.getline(accountType, numSize);


			// search Account for 

			for (int i = 0; i < customerCount; ++i)
			{
				if (strcmp(clientArr[i].accountNumber) == 0)
				{
					cout << "Account Number : " << clientArr[i].accountNumber << endl;
					cout << "Account Type : " << clientArr[i].accountType << endl;
					cout << "cid : " << clientArr[i].iNumber << endl;
					break;
				}

				else {
					cout << "there are no client who you are looking for... " << endl;
					break;
				}
				system("pause");


			}
		case menu_sort:
			system("cls");


			break;

			cout << "wrong choice" << endl;

		}
		system("pause");
		return 0;

		}

	//void calculateAmount() {
	//	int a = ;
	//	int b = ;
	//}